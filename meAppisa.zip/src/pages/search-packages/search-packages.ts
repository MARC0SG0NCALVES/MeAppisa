import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-search-packages',
  templateUrl: 'search-packages.html'
})
export class SearchPackagesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
