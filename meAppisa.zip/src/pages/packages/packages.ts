import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-packages',
  templateUrl: 'packages.html'
})
export class PackagesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
